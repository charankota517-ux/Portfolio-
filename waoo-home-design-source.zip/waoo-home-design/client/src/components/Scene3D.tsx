import { useState } from "react";
import { Info, Rotate3D, Sparkles } from "lucide-react";

type RoomConfig = { wall: string; floor: string };

const hotspots = [
  { id: "light", label: "Sculptural pendant", x: "56%", y: "18%", title: "Brass Cloud Pendant", detail: "Hand-finished brass · ambient 2700K glow" },
  { id: "sofa", label: "Lounge seating", x: "37%", y: "58%", title: "Bespoke boucle lounge", detail: "Ivory boucle · rounded architectural silhouette" },
  { id: "console", label: "Material library", x: "76%", y: "54%", title: "Walnut + stone palette", detail: "American walnut · brushed brass · Kota stone" },
];

export default function Scene3D({ wall, floor, onSelect }: { wall: string; floor: string; onSelect?: (title: string) => void }) {
  const [active, setActive] = useState(hotspots[0]);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const wallColor = wall === "sage" ? "#526458" : wall === "blue" ? "#273b55" : "#b8a993";
  const floorColor = floor === "concrete" ? "#565653" : floor === "marble" ? "#bbb9b0" : "#8d6448";

  function handleMove(e: React.MouseEvent<HTMLDivElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    setTilt({ x: ((e.clientY - r.top) / r.height - 0.5) * -7, y: ((e.clientX - r.left) / r.width - 0.5) * 8 });
  }

  return (
    <div className="scene-shell" onMouseMove={handleMove} onMouseLeave={() => setTilt({ x: 0, y: 0 })}>
      <div className="scene-badge"><Rotate3D size={14} /> drag your gaze around</div>
      <div className="room-stage" style={{ transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}>
        <div className="room-wall" style={{ background: `linear-gradient(135deg, ${wallColor}, #161817 78%)` }} />
        <div className="room-window"><div className="window-sky" /><div className="window-frame frame-v" /><div className="window-frame frame-h" /></div>
        <div className="room-slatwall" />
        <div className="room-floor" style={{ backgroundColor: floorColor }} />
        <div className="room-rug" />
        <div className="room-sofa"><div className="cushion c1" /><div className="cushion c2" /><div className="sofa-base" /></div>
        <div className="room-table"><div className="table-top" /><div className="table-leg left" /><div className="table-leg right" /></div>
        <div className="room-plant"><div className="plant-stem s1" /><div className="plant-stem s2" /><div className="plant-stem s3" /><div className="plant-pot" /></div>
        <div className="room-pendant"><div className="pendant-cord" /><div className="pendant-light" /></div>
        <div className="room-glow" />
        {hotspots.map((spot) => <button key={spot.id} className={`hotspot ${active.id === spot.id ? "is-active" : ""}`} style={{ left: spot.x, top: spot.y }} onClick={() => { setActive(spot); onSelect?.(spot.title); }} aria-label={spot.label}><span /><i /></button>)}
      </div>
      <div className="scene-caption"><div><span className="eyebrow">LIVE PREVIEW / 01</span><strong>{active.title}</strong><small>{active.detail}</small></div><Info size={17} /></div>
    </div>
  );
}

export function RoomLegend({ config }: { config: RoomConfig }) {
  return <div className="room-legend"><Sparkles size={15} /><span>Previewing: <b>{config.wall === "sage" ? "Sage" : config.wall === "blue" ? "Royal Blue" : "Warm Beige"}</b> wall / <b>{config.floor}</b> finish</span></div>;
}
