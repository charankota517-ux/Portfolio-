import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, CalendarDays, Check, ChevronDown, Clock3, Compass, Instagram, Mail, MapPin, Menu, Phone, Play, Quote, Send, Sparkles, X } from "lucide-react";
import Scene3D, { RoomLegend } from "@/components/Scene3D";

const gold = "#d5b26a";
const services = [
  { n: "01", title: "Complete interior planning", text: "A considered spatial story — from first sketch to final styling.", icon: "⌂" },
  { n: "02", title: "Custom furniture & decor", text: "Pieces selected for proportion, texture, and the way you live.", icon: "◒" },
  { n: "03", title: "Modern modular kitchens", text: "Quietly clever kitchens, designed around your daily rituals.", icon: "▦" },
  { n: "04", title: "3D walkthroughs", text: "See the mood, material, and light before a single detail is built.", icon: "◉" },
];
const projects = [
  { title: "The Walnut Residence", tag: "Residential · Solapur", image: "/manus-storage/waoo-hero-room_660d33ea.jpg" },
  { title: "Material / Matter", tag: "Studio study · 2024", image: "/manus-storage/waoo-material-detail_4a425c69.jpg" },
];

export default function Home() {
  const [menu, setMenu] = useState(false);
  const [wall, setWall] = useState("beige");
  const [floor, setFloor] = useState("Marble");
  const [submitted, setSubmitted] = useState(false);
  const [selected, setSelected] = useState("");

  const scrollTo = (id: string) => { document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); setMenu(false); };

  return <div className="site-shell">
    <header className="nav-wrap"><a className="brand" href="#top" onClick={() => scrollTo("top")}><span className="brand-mark">W</span><span>WAOO<small>HOME DESIGN STUDIO</small></span></a><nav className={menu ? "mobile-open" : ""}>{["Studio", "Services", "3D Lab", "Contact"].map((item) => <button key={item} onClick={() => scrollTo(item === "3D Lab" ? "lab" : item === "Contact" ? "contact" : item.toLowerCase())}>{item}</button>)}<button className="nav-cta" onClick={() => scrollTo("contact")}>Book consultation <ArrowUpRight size={15} /></button></nav><button className="menu-button" onClick={() => setMenu(!menu)} aria-label="Toggle menu">{menu ? <X /> : <Menu />}</button></header>

    <main id="top">
      <section className="hero" id="studio"><div className="hero-image" /><div className="hero-vignette" /><div className="hero-content"><p className="kicker"><span /> Interior architecture / Solapur, Maharashtra</p><h1>Spaces with<br /><em>a point of view.</em></h1><p className="hero-copy">Thoughtful interiors shaped by light, material and the quiet details that make a house feel like yours.</p><div className="hero-actions"><button className="button button-gold" onClick={() => scrollTo("lab")}>Explore the 3D lab <ArrowUpRight size={17} /></button><a className="button button-ghost" href="tel:+919209597979"><Phone size={15} /> 092095 97979</a></div><div className="hero-meta"><span>01 / 04</span><div className="meta-line"><i /></div><span>Crafted in Solapur</span></div></div><div className="hero-side-note">Scroll to explore <span>↓</span></div></section>

      <section className="intro section-pad"><div className="section-label">/ The studio</div><div className="intro-grid"><div><h2>We design for<br /><em>how you want to feel.</em></h2></div><div className="intro-body"><p className="large-copy">WAOO is an interior and architectural design studio for homes that feel personal, layered and alive.</p><p>From our studio in Ganesh Peth, we bring together planning, 3D visualization, custom furniture and material intelligence to create spaces that hold their value — visually and emotionally.</p><button className="text-link" onClick={() => scrollTo("services")}>Discover our approach <ArrowUpRight size={16} /></button></div></div><div className="stats"><div><strong>12+</strong><span>Years of making</span></div><div><strong>180</strong><span>Spaces transformed</span></div><div><strong>01</strong><span>Studio in Solapur</span></div></div></section>

      <section className="services section-pad" id="services"><div className="section-head"><div><div className="section-label">/ What we do</div><h2>One studio.<br /><em>Every layer of home.</em></h2></div><p>Our process moves effortlessly between the big picture and the smallest tactile detail.</p></div><div className="service-grid">{services.map((service, i) => <motion.article className="service-card" key={service.n} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: i * .08 }} viewport={{ once: true }}><span className="card-number">{service.n}</span><span className="service-icon">{service.icon}</span><h3>{service.title}</h3><p>{service.text}</p><ArrowUpRight className="card-arrow" size={20} /></motion.article>)}</div></section>

      <section className="lab section-pad" id="lab"><div className="section-head lab-head"><div><div className="section-label">/ The 3D lab</div><h2>Change the mood.<br /><em>Find your room.</em></h2></div><p>Play with the palette. Our interactive preview gives you a feeling for the room before the first site visit.</p></div><div className="lab-grid"><div className="scene-frame"><Scene3D wall={wall} floor={floor} onSelect={setSelected} /><div className="selected-toast">{selected ? <><Check size={14} /> {selected} added to your board</> : <>Click a pin to inspect the details</>}</div></div><aside className="lab-controls"><span className="eyebrow">YOUR MATERIAL BOARD</span><h3>Start with a feeling.</h3><p>Small shifts in colour and finish change the entire rhythm of a space.</p><div className="control-group"><label>01 / Wall colour</label><div className="swatches">{[["beige", "Warm beige"], ["sage", "Sage green"], ["blue", "Royal blue"]].map(([value, label]) => <button key={value} className={wall === value ? "swatch selected" : "swatch"} onClick={() => setWall(value)}><i style={{ background: value === "beige" ? "#b8a993" : value === "sage" ? "#526458" : "#273b55" }} />{label}</button>)}</div></div><div className="control-group"><label>02 / Floor finish</label><div className="finish-list">{["Marble", "Hardwood", "Concrete"].map((item) => <button key={item} className={floor === item ? "finish selected" : "finish"} onClick={() => setFloor(item)}>{item}<span>{floor === item ? "Selected" : ""}</span></button>)}</div></div><RoomLegend config={{ wall, floor }} /></aside></div></section>

      <section className="projects section-pad"><div className="section-head"><div><div className="section-label">/ Selected work</div><h2>Rooms that stay<br /><em>with you.</em></h2></div><button className="text-link">View all projects <ArrowUpRight size={16} /></button></div><div className="project-grid">{projects.map((project, i) => <article className={`project-card p${i}`} key={project.title}><img src={project.image} alt={project.title} /><div className="project-overlay"><span>{project.tag}</span><h3>{project.title}</h3><ArrowUpRight size={22} /></div></article>)}</div></section>

      <section className="quote-band"><div className="quote-mark"><Quote size={30} /></div><blockquote>“The best rooms are not decorated.<br /><em>They are composed.</em>”</blockquote><span>— WAOO studio note / 001</span></section>

      <section className="contact section-pad" id="contact"><div className="contact-grid"><div><div className="section-label">/ Let’s make a place</div><h2>Bring us your<br /><em>blank canvas.</em></h2><p className="contact-copy">Tell us a little about your project. We’ll come back with a thoughtful next step.</p><div className="contact-details"><a href="tel:+919209597979"><Phone size={16} /> +91 092095 97979</a><a href="mailto:hello@waoohome.com"><Mail size={16} /> hello@waoohome.com</a><span><MapPin size={16} /> Mangalwar Bazar, Solapur 413005</span></div></div><form className="booking-form" onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}><div className="form-row"><label>Your name<input required placeholder="e.g. Ananya Deshmukh" /></label><label>Phone number<input required type="tel" placeholder="+91" /></label></div><label>Project type<select defaultValue=""><option value="" disabled>Select a direction</option><option>Residential interior</option><option>Commercial space</option><option>Renovation</option></select></label><label>Preferred date<input required type="date" /></label><button className="button button-gold" type="submit">{submitted ? <><Check size={17} /> Request received</> : <>Request a consultation <Send size={15} /></>}</button><small>We usually reply within one working day.</small></form></div></section>
    </main>

    <footer><div className="footer-top"><a className="brand" href="#top"><span className="brand-mark">W</span><span>WAOO<small>HOME DESIGN STUDIO</small></span></a><p>Architecture, interiors<br />and the art of living well.</p><div className="socials"><a href="https://instagram.com" aria-label="Instagram"><Instagram size={17} /></a><a href="mailto:hello@waoohome.com" aria-label="Email"><Mail size={17} /></a></div></div><div className="footer-bottom"><span>© 2024 WAOO Home Design Studio</span><span>Mon — Sun / 09:00 — 19:00</span><span>Made for living, in Solapur.</span></div></footer>
  </div>;
}
